<?php
//Ключи для БД
  return array(
  'host' => 'localhost',
  'dbname' => 'test',
  'user' => 'test',
  'password' => 'password',
);
